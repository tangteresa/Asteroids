import java.util.Random; 

public class Explosion extends GameObject {
		//Create explosion at source position
		public Explosion(GameObject source) {
	      super(source, "explosion");
	      setTeam(0);
	   }
	   
		//Create explosion at random place and random velocity
	   public Explosion() {
	      super(0, 0, "explosion");
	      Random random = new Random();
	      setPosition(random.nextDouble() * screenWidth, random.nextDouble() * screenHeight);
	      setVelocity(random.nextDouble() * 10 - 5, random.nextDouble() * 10 - 5);
	   }
	   
	   //Create explosion at certain location 
	   public Explosion(double x, double y) {
	      super(x, y, "explosion");
	   
	   }
	
}
