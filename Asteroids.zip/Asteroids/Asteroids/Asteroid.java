import java.util.Random; 
import java.awt.Graphics;
import java.awt.Color; 

public class Asteroid extends GameObject {
	private double xVel, yVel;
	private int healthLevel, health; 
	Random rand; 
	
	public Asteroid(String asteroidType, int xVel, int yVel) {
		super(0, 0, asteroidType); 
		rand = new Random(); 
		
		//Spawn asteroid at random position 
		setPosition(rand.nextDouble() * 600, 600);
		
		//Each asteroid type has a certain health level 
		setHealthLevel(asteroidType); 
		health = healthLevel; 
		this.xVel = xVel; 
		this.yVel = yVel; 
		
		//Super asteroids have a bigger radius than other asteroid types 
		if(asteroidType == "superAsteroid") {
			setRadius(180); 
		} else {
			setRadius(30); 
		}
		
		setTeam(3);
		setVelocity(xVel, yVel); 	
	}
	
	//Set the health level based on the asteroid type 
	public void setHealthLevel(String asteroidType) {
		switch(asteroidType) {
			case "smallAsteroid": 
				healthLevel = 0; 
				break; 
			case "asteroid": 
				healthLevel = 1; 
				break; 
			case "midAsteroid": 
				healthLevel = 2; 
				break; 
			case "bigAsteroid": 
				healthLevel = 3; 
				break; 
			case "superAsteroid": 
				healthLevel = 35; 
				break; 
		}
	
	}
	
	//Overridden collision method 
	public void collision(GameObject other) {
		//If colliding with a coin or a health boost 
		if (other.getSprite().matches("coin") || other.getSprite().matches("white")) {
			//Do nothing
		} else if (other.getSprite().matches("laser")) {
			//Decrease health if colliding with a laser 
			if(health > 0) {
				health--; 
			} else {
				super.collision(other);
			}
			
		} else {
			super.collision(other);
		}

	}
	
	//Draw an asteroid health indicator 
    public void draw(Graphics g) {
    	super.draw(g);
    	
    	if(this.getSprite() != "superAsteroid") {
    		drawCircle(g, 30, Color.BLUE); 
        	
    		//Draw a health indicator with different colors that
    		//represent how much health is left 
        	if(healthLevel == health) {
        		g.setColor(new Color(0, 255, 0));
        	} else if (health == 0) {
        		g.setColor(new Color(255, 0, 0));
        	} else if (health == 2){
        		g.setColor(Color.ORANGE);
        	} else {
        		g.setColor(Color.YELLOW); 
        	}
        	
        	//Draw health indicator bar 
        	g.fillRect((int)(getX()-15), screenHeight - 25 - (int)(getY()), (int)((health+1) * (30.0/(healthLevel+1))), 5);

    	} else {
    		//Super asteroids have different color settings for different health levels than normal asteroids 
    		if(healthLevel == health || health > 25) {
        		g.setColor(new Color(0, 255, 0));
        	} else if (health == 0) {
        		g.setColor(new Color(255, 0, 0));
        	} else if (health > 15 ){
        		g.setColor(Color.ORANGE);
        	} else {
        		g.setColor(Color.YELLOW); 
        	}
    		
    		//Draw super asteroid health indicator bar 
    		g.fillRect((int)(getX()-80), screenHeight - 25 - (int)(getY()), (int)((health+1) * (150.0/(healthLevel+1))), 5);
    	}
    
   }
    
    //Vanish if off the bottom
	public void offBottom() {
		vanish(); 
	}
	
	//Vanish if off the top
	public void offTop() {
		vanish(); 
	}
	
	//Vanish if offscreen
	public void offScreen() {
		vanish(); 
	}
	
	//Explode when dying 
	public void die(){
		super.die();
		new Explosion(this); 
	}

}


