import java.util.Random; 

public class Coin extends GameObject {
	private double xVel, yVel; 
	Random rand; 
	
	public Coin() {
		super(0, 0, "coin"); 
		rand = new Random(); 
		
		//Spawn at random position
		setPosition(rand.nextDouble() * 600, 600);
		
		xVel = 0;
		yVel = -5; 
		
		setTeam(2);
		setVelocity(xVel, yVel); 	
	}
	
	public void collision(GameObject other) {
		//If coin hits asteroid of any type 
		if (other.getSprite().indexOf("steroid") != -1) {
			//Do nothing
		} else {
			super.collision(other);
		}

	}
	
	//Vanish when off screen 
	public void offScreen() { 
		vanish();
	}
}
