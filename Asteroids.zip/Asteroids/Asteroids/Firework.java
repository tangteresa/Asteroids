import java.util.Random; 
import java.awt.Graphics;

public class Firework extends Powerup {
	Random rand; 
	Ship master; 
	
	//Create firework on ship 
	public Firework(Ship source) {
		super(source, "yellow"); 
				
		setCost(15); 
		setLifespan(320); 
		setTeam(1); 
		activate(); 
		master = source; 
		rand = new Random(); 
	}
			
		//Create firework at certain location
		public Firework(int x, int y) {
			super(x, y, "yellow"); 
			setCost(15); 
			deactivate(); 
		}
			
		//Creates a firework with no sprite
		public Firework() {
			super(); 
			setCost(15); 
			deactivate(); 
		}
		
		public void collision(GameObject other) {
			//If the firework touches a laser of any type, it won't die
			if(other.getSprite().indexOf("laser") != -1) {
				//Do nothing 
			} else {
				super.collision(other);
			}
		
		}
		
		public void sprayLasers() {
			//Random velocity between -30 and 30
			new Laser(master, (rand.nextInt(61) - 30), (rand.nextInt(61) - 30), randomColorLaser()); 
			new Laser(master, (rand.nextInt(61) - 30), (rand.nextInt(61) - 30), randomColorLaser()); 
		}
		
		//Create laser of random color 
		public String randomColorLaser() {
			int color = rand.nextInt(4) + 1; 
			String laserSprite = ""; 
			
			switch(color) {
				case 1: 
					laserSprite = "bluelaser"; 
					break;
				case 2: 
					laserSprite = "redlaser"; 
					break; 
				case 3:
					laserSprite = "greenlaser"; 
					break; 
				case 4: 
					laserSprite = "laser"; 
					break; 
			}
			//Return laser color 
			return laserSprite; 
		}
		
		//Overridden method of step
		public void step() {
			//If firework is activated, perform its special ability 
			if(isActivated()) {
				sprayLasers(); 
			}
			
			super.step(); 
		}

}
