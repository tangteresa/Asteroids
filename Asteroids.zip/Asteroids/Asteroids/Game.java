import java.util.Random;
import java.awt.Graphics; 
import java.awt.Color;

public class Game extends GameObject {
	private int counter; 
	private double distance; 
	private double distanceLeft; 
	Random rand = new Random(); 
	GameObject planetX; 
	Ship player = new Ship();
	
    public Game() {
        super(); 
        
        this.counter = 0;
        
        //Set distance to planet X
        distance = 54600000; 
        distanceLeft = distance; 
        
        //Create store 
        new Store(); 
        
    }
    
    //Return the time 
    public int getCounter() {
    	return this.counter; 
    }
    
    //Kill the player's powerup when the powerup has lasted a certain number of seconds 
    public void powerupTimeUp() {
    	if((counter != 0) && (counter == (player.getPowerup()).getKillTime())) {
    		player.killPowerup();  
		}	
 
    }
    
    //Draw distance counter 
    public void draw(Graphics g) {
    	g.setColor(Color.CYAN);
    	g.drawString("Distance to Planet X: " + Double.toString(distanceLeft) + " km", 20, 25);
    }
    
    //1% chance of getting a health boost onscreen
    public void healthBoost() {
    	if(rand.nextInt(100) + 1 == 1) {
			new HealthBoost(); 
		}
    }

    
    public void step() {
		
		//Calculate the distance left to travel until Planet X 
		distanceLeft = distance - (counter * 9100); 
		
		//Show planet X when ship is close
		if(distanceLeft == 9100) {
			planetX = new GameObject(600, 600, "planetX"); 
		}
		
		//End game when planet X is reached
		if(distanceLeft < 0) {
			//Stop the distance counter
			distanceLeft = 0; 
			gameOver(); 
			player.vanish(); 
		}
		
		//Levels of difficulty based on time 
    	if(counter < 1400) {
    		//Easiest level 
    		if(counter%30 == 0) {
        		new Asteroid("smallAsteroid", 0, -5); 
        		new Asteroid("smallAsteroid", 0, -5); 
        		new Asteroid("smallAsteroid", 0, -5); 
        		new Coin(); 
        		new Coin(); 
        	}
    	
    	} else if (counter < 2000){
    		if(counter%15 == 0) {
        		new Asteroid("smallAsteroid", 0, -10); 
        		new Asteroid("smallAsteroid", 0, -10); 
        		new Asteroid("smallAsteroid", 0, -10); 
        		new Coin(); 
        	} 
    		
    
    	} else if (counter < 2600) {
    		if(counter%15 == 0) {
    			new Asteroid("asteroid", 0, -10); 
    			new Asteroid("asteroid", 0, -10); 
    			new Asteroid("smallAsteroid", 0, -10); 
    			new Coin(); 
    		}
    		
  
    	} else if (counter < 3400) {
    		if(counter%15 == 0) {
    			new Asteroid("midAsteroid", 0, -15); 
    			new Asteroid("midAsteroid", 0, -15); 
    			new Asteroid("midAsteroid", 0, -15); 
    			new Coin(); 
    		
    		}
    		//Create health boosts 
    		healthBoost();
    		
    	} else if (counter < 4200) {
    		if(counter%10 == 0) {
    			new Asteroid("bigAsteroid", 0, -15); 
    			new Asteroid("bigAsteroid", 0, -15); 
    			new Asteroid("bigAsteroid", 0, -15); 
    			new Coin(); 
    		}
    		//Create health boosts 
    		healthBoost();
    		
    	} else if (counter > 4200) {
    		//Hardest level 
    		if(counter%10 == 0) {
    			new Asteroid("bigAsteroid", 0, -17); 
    			new Asteroid("bigAsteroid", 0, -17); 
    			new Coin(); 
    		} 
    		//Spawn super asteroids 
    		if(counter%720 == 0) {
    			new Asteroid("superAsteroid", 0, -1); 
    		}
    		//Create health boosts
    		healthBoost(); 
   
    	} 
    	
    	//If ship has a powerup
    	if(player.hasPowerup()) {
    		//Determine when the powerup's time is up 
    		powerupTimeUp(); 

    	}
    	
    	//Send current time to the ship 
    	player.setCounter(counter);
    	
    	counter++;
    	super.step();
    }

}

