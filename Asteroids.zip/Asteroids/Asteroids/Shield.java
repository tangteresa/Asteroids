import java.util.ArrayList;
import java.util.Random; 

public class Shield extends Powerup {
	//Set circling laser's radius 
	private int r; 
	
	//Set parameter for circling laser to step through 
	private double t; 
	Laser laser; 
	Ship master; 
	Random rand = new Random(); 
	
	//Create shield on ship 
	public Shield(Ship source) {
		super(source, "green"); 
		
		r = 30; 
		t = 0; 
		laser = new Laser(0, 0, (source.getX() + 40), source.getY());  
		master = source; 
		setCost(25); 
		setLifespan(620); 
		setTeam(1); 
		activate(); 
	}
		
	//Create shield at certain location
	public Shield(int x, int y) {
		super(x, y, "green"); 
		setCost(25); 
		deactivate(); 
	}
		
	//Creates a shield with no sprite
	public Shield() {
		super(); 
		setCost(25); 
		deactivate(); 
	}
	
	//Use parametric equations to make circling laser move in a circle around ship 
	public void circle() {
		double xPos = r * Math.cos(t); 
		double yPos = r * Math.sin(t); 
		laser.setPosition((xPos + master.getX()), (yPos + master.getY())); 
		
	}
	
	
	//Find objects within the radius of the magnet 
		public void findNearbyObjects() {	
			//Get list of objects in the game
			ArrayList objects = super.getObjects(); 
			for(int i = 0; i < objects.size(); i++) {
				double objX = ((GameObject)objects.get(i)).getX(); 
				double objY = ((GameObject)objects.get(i)).getY(); 
					
				if(((GameObject)objects.get(i)).getSprite().indexOf("steroid")!= -1)	{
					//If object is within the magnet's radius 
					if(Math.sqrt(Math.pow((objX-this.getX()), 2) + Math.pow((objY-this.getY()), 2)) < 130) {
						//((GameObject)objects.get(i)).bounce(((GameObject)objects.get(i)), this.getMass(), ((GameObject)objects.get(i)).getMass());
						if(objX < this.getX()) {
							((GameObject)objects.get(i)).setVX(rand.nextInt(21)-20);
						} else {
							((GameObject)objects.get(i)).setVX(rand.nextInt(21)); 
						}
						
						if(objY < this.getY()) {
							((GameObject)objects.get(i)).setVY(rand.nextInt(21)-20);
						} else {
							((GameObject)objects.get(i)).setVY(rand.nextInt(21)); 
					
						}
					}
					
				}
		    }
			
		}
		
	//Overridden method of step
	public void step() {
		
		//If powerup's abilities are activated
		if(isActivated()) {
			//Circling laser circles ship
			circle();
			
			//Increase parameter t 
			if(t == 2 * Math.PI) {
				t = 0; 
			} else {
				t = t + (Math.PI/24); 
			}
			
			//Find nearby objects for shield to protect ship against 
			findNearbyObjects(); 
		}
		
		super.step(); 
	}

}
