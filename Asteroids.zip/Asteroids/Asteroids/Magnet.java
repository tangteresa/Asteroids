import java.util.ArrayList; 

public class Magnet extends Powerup {
	
	//Create magnet on ship 
	public Magnet(Ship source) {
		super(source, "blue"); 
		
		setCost(10); 
		setLifespan(620); 
		setTeam(1); 
		activate(); 
	}
	
	//Create magnet at certain location
	public Magnet(int x, int y) {
		super(x, y, "blue"); 
		setCost(10); 
		deactivate(); 
	}
	
	//Creates a magnet with no sprite
	public Magnet() {
		super(); 
		setCost(10); 
		deactivate(); 
	}

	//Find coins within the radius of the magnet 
	public void findNearbyCoins() {	
		//Get list of objects in the game
		ArrayList objects = super.getObjects(); 
		for(int i = 0; i < objects.size(); i++) {
			//If object is a coin
			if (((GameObject)objects.get(i)).getSprite().equals("coin")) 
			{
				double coinX = ((GameObject)objects.get(i)).getX(); 
				double coinY = ((GameObject)objects.get(i)).getY(); 
				
				
				//If coin is within the magnet's radius 
				if(Math.sqrt(Math.pow((coinX-this.getX()), 2) + Math.pow((coinY-this.getY()), 2)) < 130) {
					//Grab the coin by changing its velocity 
					grabCoin(coinX, coinY, (GameObject)objects.get(i)); 
				}
				
			}
	    }
		
	}
	
	
	//Change the coin's velocity based on its distance from the magnet 
	//so the coin will collide with the ship and die
	public void grabCoin(double coinX, double coinY, GameObject coin) {
		double grabSpeedY = 0.3 * Math.abs(coinY-this.getY()); 
		double grabSpeedX = 0.3 * Math.abs(coinX - this.getX()); 
		int threshold = 25;
		
		//If the coin is close enough, change its position instead of velocity
		//Otherwise, change its velocity 
		if (Math.abs(coinY - this.getY()) < threshold) {
			coin.setY(this.getY());
		} else if(coinY > this.getY()) {
			coin.setVY(-1 * grabSpeedY);
		} else if (coinY < this.getY()) {
			coin.setVY(grabSpeedY);
		}
		
		if (Math.abs(coinX - this.getX()) < threshold) {
			coin.setX(this.getX());
		} else if(coinX < this.getX()) {
			coin.setVX(grabSpeedX);
		} else if (coinX > this.getX()) {
			coin.setVX(-1 * grabSpeedX);
		}
		
	}
	
	public void step () {
		//Find nearby coins at every timeslice if magnet is activated
		if(isActivated()) {
			findNearbyCoins(); 
		}
		super.step(); 
	}
	
}
