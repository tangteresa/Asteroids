	import java.awt.Graphics;
import java.awt.Color; 

public class Ship extends GameObject {
	private double xVel, yVel; 
	private int numShots, health, counter, numCoins;  
	
	//The ship can only have one powerup equipped at a time
	private Powerup powerup; 
	
	//Indicates if the ship has a powerup 
	private boolean hasPowerup; 
	
	public Ship() {
		super(300, 200, "ship");

		//Ship has 3 health 
		health = 3; 
		hasPowerup = false; 
		setTeam(1); 
		setVelocity(xVel, yVel); 
		getKeyFocus();
		
	}
	
	public void collision(GameObject other) {
		//Increase the amount of coins when the ship hits a coin
		if(other.getSprite().matches("coin")) {
			numCoins++; 	
		} else if (other.getSprite().indexOf("steroid") != -1) {
			//Decrease health if the ship hits an asteroid of any type 
			if(health > 0) {
				health--; 
			} else {
				//If health is too low, the ship will die and the game is over 
				super.collision(other);
				new Explosion(this); 
				gameOver(); 
				this.vanish();  
			}
		} else if(other.getSprite().matches("white")) {
			//Increase health if ship collects a health boost 
			if(health != 3) {
				health++; 
			}
		} else if(other.getSprite().indexOf("laser") != -1 ) {
			//Do nothing
		} else {
			super.collision(other);
		}
	
	}
	
	//Return the powerup that the ship has equipped
	public Powerup getPowerup() {
		return this.powerup; 
	}
	
	//Returns whether the ship has a powerup 
	public boolean hasPowerup() {
		return this.hasPowerup; 
	}
	
	//Destroy the equipped powerup 
	public void killPowerup() {
		this.powerup.die(); 
		hasPowerup = false; 
	}
	
	//Set the powerup that is equipped 
	public void setPowerup(Powerup powerup) {
		//A null powerup sets the powerup reference to point at nothing
		//because the player's current powerup has died
		if(powerup == null) {
			//The player no longer has a powerup 
			hasPowerup = false; 
		}
		this.powerup = powerup; 
	}
	
	//Return the number of coins collected by the ship
	public int getNumCoins() {
		return this.numCoins; 
	}
	
	//Overriden method 
	//Draws string a little bit underneath the ship 
	public void drawString(Graphics g, String message, Color color) {
	    g.setColor(color);
	    g.drawString(message, (int)(getX()-20), screenHeight - (int)(0.75*(getY())));
	}
	
	//Draw graphics on the ship 
    public void draw(Graphics g) {
    	super.draw(g);
    	
    	//Show the number of coins the ship has 
    	drawString(g, ("Coins: " + Integer.toString(this.numCoins)), Color.BLUE); 
    	
    	//Create player health indicator 
    	//Choose indicator's color based on the amount of health remaining 
    	switch(health) {
    		case 3: 
    			g.setColor(new Color(0, 255, 0));
    			break; 
    		case 2: 
    			g.setColor(new Color(0, 255, 0));
    			break; 
    		case 1: 
    			g.setColor(new Color(255, 255, 51));
    			break; 
    		case 0: 
    			g.setColor(new Color(255, 0, 0));
    			break; 
    	}
    	//Draw health indicator bar 
    	g.fillRect((int)(getX()-15), screenHeight - (int)(0.86*getY()), (int)((health+1) * 7.5), 5);
    	
    	if(hasPowerup) {
    		//Create powerup time remaining indicator
    		g.setColor(Color.ORANGE);
    		g.drawString(("Powerup Time Remaining: " + Integer.toString((powerup.getKillTime() - counter)/20)), 420, 25);
    	}
   }
    
    //Add one to the amount of coins the ship has 
	public void increaseNumCoins() {
		this.numCoins++; 
	}
	
	//Shoot a laser when the space key is pressed 
	public void keySpacePressed() {
		new Laser(this, 0, 10);	
	}

	//Move the ship to the left 
	public void keyLeftPressed() {
		xVel = xVel - 10; 
		setVelocity(xVel, yVel); 
		
		//Change the powerup's velocity so that it stays on the ship 
		powerup.changeVelocity(this);
	}

	//Stop the ship from moving left
	public void keyLeftReleased() {
		xVel = xVel + 10; 
		setVelocity(xVel, yVel);  
		
		//Change the powerup's velocity so that it stays on the ship 
		powerup.changeVelocity(this);
	}
	
	//Move the ship to the right 
	public void keyRightPressed() {
		xVel = xVel + 10;
		setVelocity(xVel, yVel); 
		
		//Change the powerup's velocity so that it stays on the ship 
		powerup.changeVelocity(this);
	}
	
	//Stop the ship from moving right
	public void keyRightReleased() {
		xVel = xVel - 10; 
		setVelocity(xVel, yVel); 
		
		//Change the powerup's velocity so that it stays on the ship 
		powerup.changeVelocity(this);
	}
	
	//Purchase a magnet when A is pressed 
	public void keyAPressed() {
		//If ship has no powerup 
		if(!hasPowerup) {
			//Create "blank" magnet to determine if the ship has enough coins
			powerup = new Magnet(); 
			//If enough coins, equip a magnet and detract coins
			if (enoughCoins()) {
				this.numCoins = this.numCoins - powerup.getCost(); 
				powerup = new Magnet(this); 
				
				//Determine when the magnet will automatically die 
				powerup.setKillTime(counter); 
				hasPowerup = true; 
			} else {
				//Cannot purchase 
				//Do nothing 
			}
		} else {
			//Already has powerup
			//Do nothing 
		}
		
	}
	
	//Purchase a bomb when S is pressed 
	public void keySPressed() {
		//If ship has no powerup 
		if(!hasPowerup) {
			//Create "blank" bomb to determine if the ship has enough coins
			powerup = new Bomb(); 
			//If enough coins, equip a bomb and detract coins
			if (enoughCoins()) {
				this.numCoins = this.numCoins - powerup.getCost(); 
				powerup = new Bomb(this); 
						
				//Determine when the bomb will automatically die 
				powerup.setKillTime(counter); 
				hasPowerup = true; 
			} else {
				//Cannot purchase 
				//Do nothing 
			}
		} else {
			//Already has powerup
			//Do nothing 
		}

	}
	
	//Purchase a firework when D is pressed 
	public void keyDPressed() {
		//If ship has no powerup 
		if(!hasPowerup) {
			//Create "blank" firework to determine if the ship has enough coins
			powerup = new Firework(); 
			
			//If enough coins, equip a firework and detract coins
			if (enoughCoins()) {
				this.numCoins = this.numCoins - powerup.getCost(); 
				powerup = new Firework(this); 
						
				//Determine when the firework will automatically die 
				powerup.setKillTime(counter); 
				hasPowerup = true; 
			} else {
				//Cannot purchase 
				//Do nothing 
			}
		} else {
			//Already has powerup
			//Do nothing 
		}

	}
	
	
	//Purchase a shield when Z is pressed 
	public void keyZPressed() {
		//If ship has no powerup 
		if(!hasPowerup) {
			//Create "blank" shield to determine if the ship has enough coins
			powerup = new Shield(); 
			
			//If enough coins, equip a shield and detract coins
			if (enoughCoins()) {
				this.numCoins = this.numCoins - powerup.getCost(); 
				powerup = new Shield(this); 
						
				//Determine when the shield will automatically die 
				powerup.setKillTime(counter); 
				hasPowerup = true; 
			} else {
				//Cannot purchase 
				//Do nothing 
			}
		} else {
			//Already has powerup
			//Do nothing 
		}

	}
	
	
	//Determine if the ship has enough coins to purchase the powerup 
	public boolean enoughCoins() {
		if(this.numCoins >= powerup.getCost()) {
			return true; 
		} else {
			return false; 
		}
	}
	
	//Stop the ship from wrapping to the left side of the screen
	public void offRight() {
		setX(600); 
	}
	
	//Stop the ship from wrapping to the right side of the screen 
	public void offLeft() {
		setX(0); 
	}
	
	//Set the time so the ship knows how much time has passed in the game
	public void setCounter(int counter) {
		this.counter = counter; 
	}
}
