
public class Powerup extends GameObject {
	private int cost;
	private int lifespan; 
	private int killTime; 
	private boolean activate; 
	
	//This is the ship that controls the powerups 
	Ship master; 
	
	//Create powerup of a certain sprite type (ex. magnet) on the ship 
	public Powerup (Ship source, String spriteName) {
		super(source, spriteName); 
		master = source; 
	}
	
	//Create powerup sprite at any location 
	public Powerup(int x, int y, String spriteName) {
		super(x, y, spriteName); 
	}
	
	//Create a "blank" powerup 
	public Powerup () {
	
	}
	
	public void collision(GameObject other) {
		//If the powerup collides with a coin or a health boost, it won't die
		if(other.getSprite().matches("coin") || other.getSprite().matches("white")) {
			//Do nothing 
		} else {
			super.collision(other);
		}
	
	}
	
	//Determine when the powerup's time is up 
	public void setKillTime(int counter) {
		killTime = counter + getLifespan(); 
	}
	
	//Return when the powerup will die automatically 
	public int getKillTime() {
		return this.killTime; 
	}
	
	//Return the amount of time the powerup will exist 
	public int getLifespan() {
		return this.lifespan; 
	}
	
	//Set the amount of time the powerup exists 
	public void setLifespan(int lifespan) {
		this.lifespan = lifespan; 
	}
	
	//Return the cost of this powerup
	public int getCost() {
		return this.cost; 
	}
	
	//Change the cost of this powerup
	public void setCost(int cost) {
		this.cost = cost; 
	}
	
	//Change the velocity of this powerup
	public void changeVelocity(GameObject source) {
		this.setVelocity(source.getVX(), source.getVY()); 
	}
	
	//Change the master ship's powerup to be null 
	public void nullifyPowerup() {
		master.setPowerup(null); 
	}
	
	//Set the player's powerup to null when the powerup dies 
	public void death() {
		nullifyPowerup(); 
	}
	
	//Activate the powerup
	public void activate() {
		this.activate = true; 
	}
	
	//Deactivate the powerup
	public void deactivate() {
		this.activate = false; 
	}
	
	//Check if powerup is activated
	public boolean isActivated() {
		return this.activate; 
	}
	
	//Prevent the powerup from wrapping to the left side of the screen 
	public void offRight() {
		setX(600); 
	}
	
	//Prevent the powerup from wrapping to the right side of the screen 
	public void offLeft() {
		setX(0); 
	}
	
}

