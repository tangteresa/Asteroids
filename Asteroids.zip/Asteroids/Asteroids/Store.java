import java.awt.Graphics; 
import java.awt.Color; 

public class Store extends GameObject {
	//Store products
	Magnet magnet; 
	Bomb bomb;
	Firework firework; 
	Shield shield; 
	
	public Store() {
		super(); 
		
		//Create store products at certain locations
        magnet = new Magnet(80, 20); 
        bomb = new Bomb(195, 20); 
        firework = new Firework(350, 20); 
        shield = new Shield(510, 20);
	}

	public void draw(Graphics g) {
		g.setColor(new Color(255,255,255));
		
		//Draw store boundary 
		g.drawLine(0, 550, 600, 550); 
		
		//Draw store product names and costs at certain locations
		g.drawString("Magnet: " + Integer.toString(magnet.getCost()) + "(Press A)", 20, 565);
		g.drawString("Bomb: " + Integer.toString(bomb.getCost()) + " (Press S)", 150, 565);
		g.drawString("Firework: " + Integer.toString(firework.getCost()) + " (Press D)", 290, 565);
		g.drawString("Shield: " + Integer.toString(shield.getCost()) + " (Press Z)", 460, 565);
	}
}
