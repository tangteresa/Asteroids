
public class Laser extends GameObject {
	private double radius; 
	
	//Create laser at object source at a certain velocity
	public Laser(GameObject source, int xVel, int yVel) {
		super(source.getX(), (source.getY() + 25), "laser"); 
		
		radius = 6;
		
		setRadius(radius);
		setVelocity(xVel, yVel); 
		setTeam(2); 
	}
	
	//Create laser of a specific type at object source and with certain velocity
	public Laser(GameObject source, int xVel, int yVel, String spriteName) {
		super(source.getX(), (source.getY() + 25), spriteName); 
		
		radius = 6; 
		
		setRadius(radius);
		setVelocity(xVel, yVel); 
		setTeam(2); 
	}
	
	//Create laser at certain location and with certain velocity
	public Laser(int xVel, int yVel, double x, double y) {
		super(x, y, "laser"); 
		
		radius = 6; 
		
		setRadius(radius);
		setVelocity(xVel, yVel); 
		setTeam(2); 
	}
	
	//Vanish when offscreen
	public void offScreen() { 
		vanish(); 
	}
}
