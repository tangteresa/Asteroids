import java.util.Random; 

public class HealthBoost extends Powerup {
	Random rand; 
	
	public HealthBoost() {
		super(0,0,"white"); 
		
		rand = new Random(); 
		
		//Spawn at random location
		setPosition(rand.nextDouble() * 600, 600);
		setTeam(2); 
		setVX(0); 
		setVY(-10); 
	}
	
	
	public void collision(GameObject other) {
		//If colliding with an asteroid 
		if (other.getSprite().indexOf("steroid") != -1) {
			//Do nothing		
		} else {
			super.collision(other);
		}

	}
	
	public void death() {
		//Do nothing
	}
	
	//Vanish when off screen
	public void offScreen() {
		vanish(); 
	}
}

