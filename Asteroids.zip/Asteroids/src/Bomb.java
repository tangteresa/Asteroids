import java.awt.Graphics;
import java.util.ArrayList;
import java.awt.Color; 

public class Bomb extends Powerup {
	
	//Create bomb on ship 
	public Bomb(Ship source) {
		super(source, "red"); 
			
		setCost(20); 
		setLifespan(80); 
		setTeam(1); 
		activate(); 
	}
		
	//Create bomb at certain location
	public Bomb(int x, int y) {
		super(x, y, "red"); 
		setCost(20); 
		deactivate(); 
	}
		
	//Creates a bomb with no sprite
	public Bomb() {
		super(); 
		setCost(20); 
		deactivate(); 
	}
	
	//Kill all asteroids on the screen
	public void killAsteroids() {
		//Get list of objects in the game
		ArrayList objects = super.getObjects(); 
		for(int i = 0; i < objects.size(); i++) {
			//If spriteName contains "steroid" then it must be an asteroid of some type 
			//The "a" in asteroid isn't included because it could be uppercase or lowercase 
			if(((GameObject)objects.get(i)).getSprite().indexOf("steroid") != -1) {
				((GameObject)objects.get(i)).die(); 
			}
		}
		
	}
	
	public void step() {
		//If powerup is activated
		if(isActivated()) {
			//Destroy all nearby asteroids 
			killAsteroids(); 
		}
		super.step(); 
	}
}
